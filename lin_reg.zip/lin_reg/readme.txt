Inledning: 

I detta projketet så skulle vi elever realisera ett inbyggt system
där då koda för en temperatur avkännar som tränar sig själv och hittar 
eller det vill säga känna av temperaturen i rummmet.


Diskussion:

Detta projketet var mycket lärorik då jag fick lära mig väldigt bra och
användbara funktioner och nyckel ord genom C och C++, 
så samtidtigt så hade projketet sina utmaningar 
att kunna träna temp_sensorn att känna av 
temperaturen var inte så lätt då man behövde få till detta i interrupts.cpp via 
nedtrcykning av tryckknappen. Med hjälp av handlare i projketet och datablad så fick jag ett lyckat
resultat och allt blev såsom jag hade tänkt mig och projketet krävde av mig.

I detta projketet så fick jag chansen att bekanta mig med klasstemplate då man kan
skapa sin egen vector eller array som kan ha 
olika datatyper.