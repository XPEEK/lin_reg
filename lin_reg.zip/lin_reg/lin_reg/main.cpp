#include "header.hpp"

int main(void)
{
	setup();
	//const double x[] = { 0, 130, 140, 150, 160, 170, 180 };
	//const double yref[] = { -50, 13.5, 18.4, 23.2, 28.2, 33.1, 38.0 };
	
	
	const double train_in[] = { 0, 130, 140, 150, 160, 170, 180 };
	const double train_out[] = { -50, 13.5, 18.4, 23.2, 28.2, 33.1, 38.0 };

    // lin_reg l1;
	// l1.set_training_data(x, yref, 7);
	l1.set_training_data(train_in, train_out, 7);
	l1.train(1000, 0.0000003);
	// l1.predict(0,180);
	
	while (1)
	{
		
	}
	
	return 0;
}