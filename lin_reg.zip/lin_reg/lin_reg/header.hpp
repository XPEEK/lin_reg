
#ifndef HEADER_HPP_
#define HEADER_HPP_

/* Inkluderingsdirektiv */
#include "def.hpp"
#include "serial.hpp"
#include "lin_reg.hpp"
#include "ADC.hpp"

/* Makrodefinitioner */
#define INTERRUPT_TIME 16.384 /* 16.384 ms mellan timeravbrott. */
#define DELAY_TIME 60000
#define NUM_INTERRUPTS (uint32_t)(DELAY_TIME / INTERRUPT_TIME + 0.5) 

#define BUTTON 5
#define BUTTON_IS_PRESSED (PINB & (1 << BUTTON))
#define TEMP_SENSOR 1

/* Externa funktioner: */
void setup(void);

/* Globala datamedlemmar: */
extern lin_reg l1;

#endif /* HEADER_HPP_ */