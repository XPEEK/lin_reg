/* Inkluderingsdirektiv */
#include "header.hpp"


/*****************************************************************************************
* F�r att ber�kna antalet exekverade avbrott,
* s� kan sedan en global variabel executed_interrupt anv�ndas,
*****************************************************************************************/
static volatile uint32_t executed_interrupts = 0;

/*****************************************************************************************
* Funktionen predict_temp: Detta �r en funktionen som predikterar temperaturen.
*****************************************************************************************/
static void predict_temp(void)
{
	const auto ADC_result = (double)ADC_read(TEMP_SENSOR);
	const auto temp = l1.predict(ADC_result);
	serial_print_integer("Predicted temperature: %ld degrees\n", (int32_t)(temp + 0.5));
	executed_interrupts = 0;
}

/*****************************************************************************************
* Avbrottsrutin: f�r PCI-avbrott PCINT5 p� PIN 13 / PORTB5. P� positiv flank, vilket �ger
*				 rum vid nedtryckning av tryckknappen, s� togglas aktivering av AD-omvandlaren vi
*			     variabeln ADC_enabled.
*****************************************************************************************/
ISR (PCINT0_vect)
{
	if (BUTTON_IS_PRESSED)
	{
		predict_temp();
		executed_interrupts = 0x00;
	}
}

/****************************************************************************************
* Avbrottsrutin: f�r overflow-avbrott p� Timer 0 i Normal Mode. Varje avbrott som �ger
*				 rum r�knas och lagras i variabeln executed_interrupts.
*			     f�ljt av att antalet exekverade avbrott s�tts till noll inf�r n�sta f�rdr�jning.
*			     Eftersom uppr�kningarna sker v�ldigt fort s�finns en risk att uppr�kningen av antalet exekverade 
*				 avbrott blir fel, vilket �r anledningen till att if-satsens villkor �r sant 
*				 ifall antalet exekverade avbrott �r st�rre eller lika med antalet avbrott 
*				 som kr�vs f�r �nskad f�rdr�jningstid.
****************************************************************************************/
ISR (TIMER0_OVF_vect)
{
   
   if (++executed_interrupts >= NUM_INTERRUPTS) // F�r en minut
   {
	   predict_temp();
	   executed_interrupts = 0x00;
   }
}