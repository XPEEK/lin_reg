#ifndef ADC_HPP_ 
#define ADC_HPP_

#define F_CPU 16000000UL

#include <avr/io.h> /* Bibliotek f�r implementering av I/O g�llande AVR-enheter. */
#include <avr/interrupt.h> /* Bibliotek f�r avbrott. */
#include <util/delay.h> /* Bibliotek f�r genenering av f�rdr�jningstid. */
#include <stdio.h> /* Bibliotek f�r implementering av I/O i C. */
#include <stdlib.h> /* C:s standardbibliotek. */

#define VCC 5.0f
#define ADC_MAX 1023

uint16_t ADC_read(const uint8_t pin);

#endif /* ADC_HPP_*/