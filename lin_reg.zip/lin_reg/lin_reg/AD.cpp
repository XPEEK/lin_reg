#include "ADC.hpp"

/*************************************************************************************************************
* Funktionen ADC_read: anv�nds f�r att l�sa insignalen fr�n potentiometern och AD-omvandla
*					   denna till ett heltal mellan 0 - 1023. D�rmed genomf�rs en AD-omvandling p�
*					   potentiometerns PIN, d�r intern matningssp�nning anv�nds. D�refter genomf�rs en
*					   AD-omvandling med h�gsta m�jliga prescaler (128), vilket medf�r en frekvens p� 125 kHz,
*					   som anv�nds f�r s� ackurat AD-omvandling som m�jligt. Efter genomf�rs AD-omvandling s�
*					   ettst�lls interrupt-flaggan ADIF, som m�ste �terst�llas manuellt via mjukvaran f�r att
*					   kunna signalera n�r n�sta AD-omvandling �r slutf�rd. D�refter returneras resultatet
*					   fr�n AD-omvandlingen vid �terhoppet.
***************************************************************************************************************/
uint16_t ADC_read(const uint8_t pin)
{
	ADMUX = (1 << REFS0) | pin;
	ADCSRA = (1 << ADEN) | (1 << ADSC) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
	while ((ADCSRA & (1 << ADIF)) == 0) ;
	ADCSRA = (1 << ADIF);
	return ADC;
}




