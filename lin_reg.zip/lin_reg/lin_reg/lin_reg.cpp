
/********************************************************************************
* lin_reg.cpp: Definition av funktionsmedlemmar tillh�rande strukten lin_reg,
*              som anv�nds f�r implementering av maskininl�rningsmodeller
*              som baseras p� linj�r regression.
********************************************************************************/
#include "lin_reg.hpp"

lin_reg::lin_reg(const double* train_in, const double* train_out, const uint8_t num_sets)
{
	this->set_training_data(train_in, train_out, num_sets);
	return;
}

/********************************************************************************
* set_training_data: L�ser in tr�ningsdata f�r angiven regressionsmodell via
*                    passerad in- och utdata, tillsammans med att index
*                    f�r respektive tr�ningsupps�ttning lagras.
*
*                    - train_in   : Inneh�ller indata f�r tr�ningsupps�ttningar.
*                    - train_out: Inneh�ller utdata f�r tr�ningsupps�ttningar.
********************************************************************************/
void lin_reg::set_training_data(const double* train_in, const double* train_out, const uint8_t num_sets)
{
	this->train_in = train_in;
	this->train_out = train_out; 
	
	if (num_sets > MAX_SETS)
	{
		this->num_sets = MAX_SETS;
	}
	else
	{
		this->num_sets = num_sets;
	}
	
	for (uint8_t i = 0; i < this->num_sets; ++i)
	{
		this->train_order[i] = i; // L�gger till index f�r tr�ningsupps�ttningarna.
	}
	
	return;
	
}

/********************************************************************************
* train: Tr�nar angiven regressionsmodell under angivet antal epoker med
*        angiven l�rhastighet. F�r varje epok randomiseras ordningsf�ljden
*        som tr�ningsdatan anv�nds f�r att undvika att modellen inte blir
*        f�r bekant med tr�ningsdatan (vi undviker overfitting).
*
*        - num_epochs   : Antalet omg�ngar tr�ning som skall genomf�ras.
*        - learning_rate: L�rhastighet, avg�r justeringsgraden.
********************************************************************************/
void lin_reg::train(const uint32_t num_epochs, const double learning_rate)
{
	for (uint32_t i = 0; i < num_epochs; ++i)
		{
			this->shuffel();
			
			for (uint8_t j = 0; j < num_sets; ++j)
			{
				const auto k = this->train_order[j];
				this->optimize(this->train_in[k], this->train_out[k], learning_rate);
			}
		}
}

/********************************************************************************
* predict: Genomf�r prediktion med angiven regressionsmodell f�r
*          datapunkter inom intervallet mellan angivet min- och maxv�rde
*          [min, max] med angiven stegringshastighet step, som s�tts till
*          1.0 som default.
*
*          Varje insignal skrivs ut tillsammans med motsvarande
*          predikterat v�rde via angiven utstr�m, d�r standardutenheten
*          std::cout anv�nds som default f�r utskrift i terminalen.
*
*          - min    : L�gsta v�rde f�r datatpunkter som skall testas.
*          - max    : H�gsta v�rde f�r datatpunkter som skall testas.
*          - step   : Stegringshastigheten, dvs. differensen mellan
*          varje datapunkt som skall testas (default = 1.0).
********************************************************************************/
void lin_reg::predict(const double min, const double max, const double step)
{
	
	const double threshold = 0.01;
	
    serial_print("---------------------------------------------------------------------------------\n");
	for (double x = min; x <= max; x += step)
	{
		const auto yp = this->predict(x);
		
		serial_print_integer("Input: %ld\n", (uint32_t)(x + 0.5));
		
		if (yp > -threshold && yp < threshold)
		{
			serial_print_integer("Predicted output: %ld\n", 0);
		}
		else 
		{
			serial_print_integer("Predicted output: %ld\n", (uint32_t)(yp + 0.5));
		}
		
		
	}
	serial_print("---------------------------------------------------------------------------------\n\n");
	return;
}

/********************************************************************************
* shuffle: Randomiserar den inb�rdes ordningen p� tr�ningsupps�ttningarna f�r
*          angiven regressionsmodell, vilket genomf�rs i syfte att minska risken
*          f�r att eventuella icke avsedda m�nster i tr�ningsdatan skall
*          p�verka tr�ningen.
********************************************************************************/
void lin_reg::shuffel()
{
	for (size_t i = 0; i < this->num_sets; ++i)
	{
		const size_t vr = rand() % this->num_sets;
		const size_t temp = this->train_order[i];
		this->train_order[i] = this->train_order[vr];
		this->train_order[vr] = temp; 
	}
	return;
}

/********************************************************************************
* optimize: Ber�knar aktuell avvikelse f�r angiven regressionsmodell och
*           justerar modellens parametrar d�refter.
*
*           input        : Insignal som prediktion skall genomf�ras med.
*           reference    : Referensv�rde fr�n tr�ningsdatan, vilket utg�r det
*                          v�rde som modellen �nskas prediktera.
*           learning_rate: Modellens l�rhastighet, avg�r hur mycket modellens
*                          parametrar justeras vid avvikelse.
********************************************************************************/
void lin_reg::optimize(const double input, const double reference, const double learning_rate)
{
	const auto prediction = this->predict(input);
	const auto deviation = reference - prediction; 
	const auto change_rate =  deviation * learning_rate;
	
	if (input == 0)
	{
		this->bias = reference; // y = kx + m
	} 
	else
	{
	   this->bias += change_rate;	
	}
	this->weight += change_rate * input;
	return; 
}