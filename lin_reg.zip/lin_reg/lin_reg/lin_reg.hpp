
/********************************************************************************
* lin_reg.hpp: Inneh�ller funktionalitet f�r enkel implementering av
*              maskininl�rningsmodeller baserade p� linj�r regression via
*              strukten lin_reg.
********************************************************************************/
#ifndef LIN_REG_H_
#define LIN_REG_H_

#include "def.hpp"
#include "serial.hpp"

/* Makrodefinitioner */
#define MAX_SETS 20


template<class T>
struct vector
{
   T* data = nullptr; // Pekare till inneh�llet.
   size_t size;      // Antalet element i vektorn.
   
   int push(T& new_element)
   {
	  auto copy = (T*)realloc(this->data, sizeof(T) * (this->size + 1));
	  if (!copy) return 1;
	  copy[this->size++] = new_element;
	  this->data = copy;
	  return 0;
   }
   
   
};

/********************************************************************************
* lin_reg: Strukt f�r implementering av maskininl�rningsmodeller baserade p�
*          linj�r regression.
********************************************************************************/
typedef struct lin_reg
{
	const double* train_in = nullptr; /* Indata f�r tr�ningsupps�tningar. */
	const double* train_out = nullptr; /* Utdata f�r tr�ningsupps�tningar. */
	uint8_t train_order[MAX_SETS]; /* Har plats f�r 20 upps�ttningar. */
	uint8_t num_sets = 0;
	double bias = get_random(); /* Vilov�rde (m-v�rde). */
	double weight = get_random(); /* Vikt (k-v�rde). */
	
	/* Medlemsfunktioner: */
	lin_reg(void) { }; 
	lin_reg(const double* train_in, const double* train_out, const uint8_t num_sets);
	void set_training_data(const double* train_in, const double* train_out, const uint8_t num_sets);
	void train(const uint32_t num_epochs, const double learning_rate);
	double predict(const double input) { return this->weight * input + this->bias; }
    void predict(const double min, const double max, const double step = 1.0);
	double get_random(void) { return rand() / static_cast<double>(RAND_MAX); }
	void shuffel(void);
	void optimize(const double input, const double reference, const double learning_rate); 
	
} lin_reg;

#endif /* LIN_REG_H_ */