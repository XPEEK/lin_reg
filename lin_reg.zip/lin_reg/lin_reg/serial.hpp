

#ifndef SERIAL_H_
#define SERIAL_H_

/* Inkluderingsdirektiv */
#include "def.hpp"

/* Makrodefinitioner */
#define ENBALE_INTERUPTS sei();
#define DISABLE_INTERUPTS cli();

#define ENABLE_SERIAL_TRANSMISSIO UCSR0B = (1 << TXEN0)
#define SET_BAUD_RATE_TO_9600_KBPS UBRR0 = 103
#define WAIT_FOR_PREVIOUS_TRANSMISSION_TO_FINISH while ((UCSR0A & (1 << UDRE0)) == 0)
#define CARRIAGE_RETURN write_byte('\r')
#define END_TRANSMISSION write_byte('\0')
#define SIZE 100
#define SET_TRANSMISSION_SIZE_TO_ONE_BYTE UCSR0C = ((1 << UCSZ00 ) | (1 << UCSZ01))

/* Funktionsdeklarationer: */
void init_serial(void);
void serial_print(const char* s);
void serial_print_integer(const char* s, const int32_t number);
void serial_print_unsigned(const char* s, const uint32_t number);
void write_byte(const char data);



#endif /* SERIAL_H_ */