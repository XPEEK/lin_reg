#include "header.hpp"

/* Statiska funktioner */
static inline void init_port();
static inline void init_interrupts();
static inline void init_ADC();
static inline void init_timer();

lin_reg l1; // Initierar objektet, anropar standardkonstruktorn.

/************************************************************************************************************
* Funktionen setup: anv�nds f�r att initiera mikrodatorn. F�rst initieras mikrodatorns
*					I/O-portar, f�ljt av att PCI-avbrott PCINT5 p� PIN 13 / PORTB5 aktiveras f�r att avbrott
*					skall ske vid nedtryckning av tryckknappen. Slutligen aktiveras AD-omvandlaren f�ljt
*					av att programmets enda globala variable ADC_enabled initieras.
*************************************************************************************************************/
void setup(void)
{
	init_serial();
	init_port();
	init_interrupts();	
	init_ADC();
	init_timer();
	return;
}

/***********************************************************************************************************
* Funktionen init_ports: anv�nds f�r att konfigurera mikrodatorns I/O-portar. 
*						 samtidigt som tryckknappens PIN 13 
                         / PORTB5 s�tts till aktiv inport (via aktivering av intern pullup-resistor). �vriga
*						 PINs s�tts till h�gohmiga inportar och blir d�rmed flytande / insignalen blir varken
*						 h�g eller l�g, vilket i praktiken inneb�r att dessa �r inaktiverade. Notera att
*						 potentiometerns PIN inte skall aktiveras via intern pullup-resistor, d� insignalen,
*						 som �r analog, skall vara flytande mellan 0 - 1.
************************************************************************************************************/
static inline void init_port()
{
	PORTB = (1 << BUTTON);
	return;
}


/************************************************************************************************************
* Funktionen init_interrupts: anv�nds f�r att aktivera PCI-avbrott PCINT5 p� tryckknappens
*							  PIN 13 / PORTB5, vilket inneb�r att avbrott sker p� logisk f�r�ndring av insignalen,
*							  allts� b�de vid nedtryckning samt uppsl�ppning av tryckknappen. Dock �r endast avbrott
*							  vid nedtryckning av tryckknappen �nskv�rt i detta fall, vilket �stadkommes via mjukvaran,
*							  d�r avbrott endast hanteras vid nedtryckning av tryckknappen.
*************************************************************************************************************/
static inline  void init_interrupts()
{
	asm("SEI");
	PCICR = (1 << PCIE0);
	PCMSK0 = (1 << BUTTON); 
	return; 
}

/************************************************************************************************************
* Funktionen init_ADC: anv�nds f�r att initiera AD-omvandlaren via en testomvandling.
*					   D�rmed genomf�rs en AD-omvandling p� PIN A0 / PORTC0, d�r intern matningssp�nning
*					   anv�nds. D�refter genomf�rs en AD-omvandling med h�gsta m�jliga prescaler (128), vilket
*                      medf�r en frekvens p� 125 kHz, som anv�nds f�r s� ackurat AD-omvandling som m�jligt.
*                      Efter att AD-omvandlingen �r slutf�rd s� ettst�lls interrupt-flaggan ADIF, som m�ste
*                      �terst�llas manuellt via mjukvaran f�r att kunna signalera n�r n�sta AD-omvandling �r
*                      slutf�rd.
*****************************************************************************************'*******************/
static inline void init_ADC()
{
	ADMUX = (1 << REFS0);
	ADCSRA = ((1 << ADEN) | (1 << ADSC) | (1 << ADPS0) | (1 << ADPS1) | (1 << ADPS2));
	while ((ADCSRA & (1 << ADIF)) == 0) ;
	ADCSRA = (1 << ADIF);
	return;
}

/************************************************************************************************************
* Funktionen init_timer: anv�nds f�r att initiera timer. 
*					     TCCR0B (Timer/Counter Control Register 0 B): Via prescaler-bitar CS00 � CS02 
*                        (Clock Select 0 bit 0 - 2) i detta register s� kan en prescaler v�ljas.
*		                 TIMSK0 (Timer Interrupt Mask Register 0):
*                        Via detta register kan olika typer av avbrott p� Timer 0 aktiveras.
*****************************************************************************************'*******************/
static inline void init_timer()
{
    asm("SEI");
    TCCR0B = ((1 << CS00) | (1 << CS02));
	TIMSK0 = (1 << TOIE0);
    return;
}